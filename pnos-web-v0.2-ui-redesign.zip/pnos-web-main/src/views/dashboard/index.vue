<template>
  <div class="pnos-page">
    <PageHeader title="Good evening." description="Everything is working normally." />

    <section class="hero-state pnos-surface">
      <div>
        <div class="eyebrow">Panda Server</div>
        <div class="health-title"><span class="health-ring"><span /></span> System healthy</div>
        <div class="health-meta">Running for {{ uptimeText }}</div>
      </div>
      <div class="hero-actions">
        <n-button quaternary @click="refresh">Refresh</n-button>
        <n-button type="primary" secondary @click="router.push('/settings')">System settings</n-button>
      </div>
    </section>

    <div class="section-head">
      <div class="pnos-section-title">Resources</div>
      <div class="section-note">Live · updates every 3s</div>
    </div>

    <n-grid :cols="4" :x-gap="14" :y-gap="14" responsive="screen" class="resource-grid">
      <n-gi span="4 s:2 m:1">
        <div class="metric pnos-surface">
          <div class="metric-label">CPU</div>
          <div class="metric-main"><strong>{{ cpuUsage }}%</strong><span>{{ systemStore.stats?.cpu?.cores || 8 }} cores</span></div>
          <div ref="cpuChartRef" class="mini-chart" />
        </div>
      </n-gi>
      <n-gi span="4 s:2 m:1">
        <div class="metric pnos-surface">
          <div class="metric-label">Memory</div>
          <div class="metric-main"><strong>{{ memoryUsage }}%</strong><span>{{ memoryDetail }}</span></div>
          <div ref="memChartRef" class="mini-chart" />
        </div>
      </n-gi>
      <n-gi span="4 s:2 m:1">
        <div class="metric pnos-surface">
          <div class="metric-label">Storage</div>
          <div class="metric-main"><strong>{{ storageUsage }}%</strong><span>{{ storageDetail }}</span></div>
          <div class="storage-bar"><span :style="{ width: `${storageUsage}%` }" /></div>
        </div>
      </n-gi>
      <n-gi span="4 s:2 m:1">
        <div class="metric pnos-surface">
          <div class="metric-label">Network</div>
          <div class="network-main"><div><strong>↓ {{ networkDown }}</strong><span>Down</span></div><div><strong>↑ {{ networkUp }}</strong><span>Up</span></div></div>
        </div>
      </n-gi>
    </n-grid>

    <n-grid :cols="2" :x-gap="14" :y-gap="14" responsive="screen" class="lower-grid">
      <n-gi span="2 s:2 m:1">
        <section class="pnos-surface panel">
          <div class="panel-header"><div><div class="pnos-section-title">Applications</div><div class="panel-subtitle">Your installed services</div></div><n-button text type="primary" @click="router.push('/store')">View all →</n-button></div>
          <div v-if="apps.length" class="app-list">
            <div v-for="app in apps" :key="app.name" class="app-row">
              <div class="app-icon"><span>{{ app.symbol }}</span></div>
              <div class="app-info"><strong>{{ app.name }}</strong><span>{{ app.description }}</span></div>
              <div class="app-state"><span class="status-dot" /> {{ app.state }}</div>
            </div>
          </div>
          <div v-else class="empty-inline">No application status is available yet.</div>
        </section>
      </n-gi>
      <n-gi span="2 s:2 m:1">
        <section class="pnos-surface panel">
          <div class="panel-header"><div><div class="pnos-section-title">Recent activity</div><div class="panel-subtitle">A quiet view of what changed</div></div></div>
          <div class="activity-list">
            <div class="activity-row"><span class="activity-dot blue" /><div><strong>System status refreshed</strong><span>Just now</span></div></div>
            <div class="activity-row"><span class="activity-dot" /><div><strong>Applications checked</strong><span>A few seconds ago</span></div></div>
            <div class="activity-row"><span class="activity-dot" /><div><strong>Background services healthy</strong><span>Today</span></div></div>
          </div>
        </section>
      </n-gi>
    </n-grid>

    <section class="notice pnos-surface">
      <div class="notice-icon">!</div>
      <div><strong>Storage looks good</strong><span>{{ storageFree }} available. We’ll let you know before it becomes a problem.</span></div>
      <n-button text type="primary" @click="router.push('/settings')">Manage storage →</n-button>
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, onUnmounted, ref, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { useSystemStore } from '@/stores/system'
import PageHeader from '@/components/PageHeader.vue'
import * as echarts from 'echarts'

const router = useRouter()
const systemStore = useSystemStore()
const cpuChartRef = ref<HTMLElement>()
const memChartRef = ref<HTMLElement>()
let cpuChart: echarts.ECharts | null = null
let memChart: echarts.ECharts | null = null
let timer: ReturnType<typeof setInterval> | null = null

const cpuUsage = computed(() => Number(systemStore.stats?.cpu?.usage ?? 0).toFixed(0))
const memoryUsage = computed(() => Number(systemStore.stats?.memory?.usage_percent ?? 0).toFixed(0))
const memoryDetail = computed(() => {
  const used = systemStore.stats?.memory?.used
  const total = systemStore.stats?.memory?.total
  return used && total ? `${formatBytes(used)} / ${formatBytes(total)}` : '—'
})
const storageSource = computed(() => systemStore.stats?.disks?.[0])
const storageUsage = computed(() => {
  const d = storageSource.value
  if (!d?.total_space) return 0
  return Number(((d.total_space - d.available_space) / d.total_space * 100).toFixed(0))
})
const storageDetail = computed(() => storageSource.value ? `${formatBytes(storageSource.value.total_space)}` : '—')
const storageFree = computed(() => storageSource.value ? formatBytes(storageSource.value.available_space) : '—')
const networkDown = computed(() => formatRate(systemStore.stats?.network?.download || systemStore.stats?.network?.rx_bytes_per_sec))
const networkUp = computed(() => formatRate(systemStore.stats?.network?.upload || systemStore.stats?.network?.tx_bytes_per_sec))
const uptimeText = computed(() => {
  const uptime = Number(systemStore.stats?.uptime || 0)
  const days = Math.floor(uptime / 86400)
  const hours = Math.floor((uptime % 86400) / 3600)
  return days ? `${days}d ${hours}h` : `${hours}h`
})

const apps = computed(() => {
  const values = systemStore.stats?.applications || systemStore.stats?.apps || []
  return Array.isArray(values) ? values.slice(0, 5).map((item: any) => ({
    name: item.name || item.id || 'Application',
    description: item.description || 'Server application',
    state: item.state || item.status || 'Running',
    symbol: (item.name || 'A').slice(0, 1).toUpperCase(),
  })) : []
})

function formatBytes(bytes: number) {
  if (!bytes) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1)
  return `${(bytes / Math.pow(1024, i)).toFixed(i > 1 ? 1 : 0)} ${units[i]}`
}
function formatRate(value: any) {
  const n = Number(value || 0)
  if (!n) return '0 B/s'
  return `${formatBytes(n)}/s`
}
function initCharts() {
  cpuChart = cpuChartRef.value ? echarts.init(cpuChartRef.value) : null
  memChart = memChartRef.value ? echarts.init(memChartRef.value) : null
  const common = { animationDuration: 350, grid: { left: 0, right: 0, top: 4, bottom: 0 }, xAxis: { show: false, type: 'category' }, yAxis: { show: false, type: 'value', min: 0, max: 100 }, tooltip: { show: false } }
  cpuChart?.setOption({ ...common, series: [{ type: 'line', smooth: true, showSymbol: false, data: [9, 12, 8, 18, 12, 14, 11, 12], lineStyle: { width: 2 }, areaStyle: { opacity: 0.08 } }] })
  memChart?.setOption({ ...common, series: [{ type: 'line', smooth: true, showSymbol: false, data: [32, 35, 34, 39, 36, 38, 38, 38], lineStyle: { width: 2 }, areaStyle: { opacity: 0.08 } }] })
}
async function refresh() {
  await systemStore.fetchStats()
}

onMounted(async () => {
  await nextTick()
  initCharts()
  refresh()
  timer = setInterval(refresh, 3000)
  window.addEventListener('resize', () => { cpuChart?.resize(); memChart?.resize() })
})
onUnmounted(() => {
  if (timer) clearInterval(timer)
  cpuChart?.dispose(); memChart?.dispose()
})
</script>

<style scoped>
.hero-state { display:flex; align-items:center; justify-content:space-between; padding:22px 24px; margin-bottom:28px; }
.eyebrow { color:var(--pnos-muted); font-size:13px; margin-bottom:7px; }
.health-title { display:flex; align-items:center; gap:10px; font-size:18px; font-weight:700; letter-spacing:-.015em; }
.health-ring { width:12px; height:12px; border-radius:50%; background:var(--pnos-success); box-shadow:0 0 0 5px var(--pnos-success-soft); display:inline-block; }
.health-meta { margin-top:7px; color:var(--pnos-muted); font-size:13px; }
.hero-actions { display:flex; gap:8px; }
.section-head { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
.section-note { color:var(--pnos-subtle); font-size:12px; }
.metric { min-height:156px; padding:18px; }
.metric-label { color:var(--pnos-muted); font-size:13px; font-weight:600; }
.metric-main { display:flex; align-items:baseline; justify-content:space-between; gap:8px; margin-top:12px; }
.metric-main strong { font-size:28px; letter-spacing:-.04em; }
.metric-main span, .network-main span { color:var(--pnos-muted); font-size:12px; }
.mini-chart { height:46px; margin-top:12px; }
.storage-bar { margin-top:26px; height:8px; border-radius:99px; background:#edf0f4; overflow:hidden; }
.storage-bar span { display:block; height:100%; background:var(--pnos-primary); border-radius:99px; }
.network-main { display:grid; grid-template-columns:1fr 1fr; gap:14px; margin-top:26px; }
.network-main strong { display:block; font-size:17px; letter-spacing:-.02em; margin-bottom:4px; }
.lower-grid { margin-top:14px; }
.panel { min-height:262px; padding:20px; }
.panel-header { display:flex; justify-content:space-between; align-items:flex-start; gap:10px; }
.panel-subtitle { font-size:12px; color:var(--pnos-muted); margin-top:-6px; }
.app-list, .activity-list { margin-top:18px; }
.app-row, .activity-row { display:flex; align-items:center; gap:11px; padding:12px 0; border-top:1px solid #f0f1f4; }
.app-row:first-child, .activity-row:first-child { border-top:0; }
.app-icon { width:34px; height:34px; border-radius:10px; display:grid; place-items:center; background:#f1f4fb; color:#3478f6; font-weight:700; }
.app-info { flex:1; min-width:0; }
.app-info strong, .activity-row strong { display:block; font-size:13px; }
.app-info span, .activity-row span { display:block; margin-top:3px; color:var(--pnos-muted); font-size:11px; }
.app-state { color:#4e5865; font-size:11px; font-weight:600; display:flex; align-items:center; gap:6px; }
.status-dot { width:6px; height:6px; border-radius:50%; background:var(--pnos-success); }
.activity-row { align-items:flex-start; }
.activity-dot { width:7px; height:7px; border-radius:50%; background:#c6cbd3; margin-top:7px; flex:none; }
.activity-dot.blue { background:var(--pnos-primary); }
.empty-inline { color:var(--pnos-muted); font-size:13px; padding:30px 0; }
.notice { display:flex; align-items:center; gap:12px; margin-top:14px; padding:15px 18px; }
.notice-icon { width:28px; height:28px; border-radius:9px; background:var(--pnos-success-soft); color:var(--pnos-success); display:grid; place-items:center; font-weight:800; }
.notice > div:nth-child(2) { flex:1; }
.notice strong { display:block; font-size:13px; }
.notice span { display:block; color:var(--pnos-muted); font-size:12px; margin-top:3px; }
@media (max-width:760px) { .hero-state { align-items:flex-start; flex-direction:column; gap:18px; } .hero-actions { width:100%; } .hero-actions .n-button { flex:1; } .notice { align-items:flex-start; flex-wrap:wrap; } }
</style>
