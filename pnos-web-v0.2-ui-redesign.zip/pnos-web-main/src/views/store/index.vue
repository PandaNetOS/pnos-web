<template>
  <div class="pnos-page">
    <PageHeader title="Apps" description="Discover and install applications for your server.">
      <template #actions>
        <n-button quaternary @click="refresh">Refresh</n-button>
      </template>
    </PageHeader>

    <div class="store-tools pnos-surface">
      <n-input v-model:value="search" clearable placeholder="Search apps" class="store-search">
        <template #prefix>⌕</template>
      </n-input>
      <div class="category-pills">
        <button v-for="item in categoryPills" :key="item.value" :class="['pill', { active: category === item.value }]" @click="category = item.value">{{ item.label }}</button>
      </div>
    </div>

    <section class="store-section">
      <div class="section-title-row"><div><div class="pnos-section-title">Featured</div><div class="section-subtitle">Curated essentials for a new server</div></div><span>{{ filteredApps.length }} apps</span></div>

      <n-grid :cols="3" :x-gap="14" :y-gap="14" responsive="screen">
        <n-gi v-for="app in featuredApps" :key="app.id" span="3 s:1 m:1">
          <article class="app-card pnos-surface" @click="showDetail(app)">
            <div class="app-card-head">
              <div class="app-logo"><span>{{ (app.name || 'A').slice(0, 1).toUpperCase() }}</span></div>
              <n-tag v-if="app.official" round size="small" type="info">Official</n-tag>
            </div>
            <h3>{{ app.name }}</h3>
            <p>{{ app.description || 'A useful service for your server.' }}</p>
            <div class="app-card-footer"><span>v{{ app.version }}</span><n-button type="primary" secondary size="small" :loading="installing === app.id" @click.stop="install(app.id)">Get</n-button></div>
          </article>
        </n-gi>
      </n-grid>
    </section>

    <section class="store-section">
      <div class="section-title-row"><div><div class="pnos-section-title">All apps</div></div></div>
      <div class="all-apps pnos-surface">
        <div v-for="app in restApps" :key="app.id" class="list-app" @click="showDetail(app)">
          <div class="app-logo small"><span>{{ (app.name || 'A').slice(0, 1).toUpperCase() }}</span></div>
          <div class="list-app-info"><strong>{{ app.name }}</strong><span>{{ app.description || 'Server application' }}</span></div>
          <n-tag v-if="app.official" round size="small" type="info">Official</n-tag>
          <n-button type="primary" secondary size="small" :loading="installing === app.id" @click.stop="install(app.id)">Get</n-button>
        </div>
        <div v-if="!restApps.length" class="empty-store">No apps match your search.</div>
      </div>
    </section>

    <n-modal v-model:show="detailVisible" :mask-closable="true">
      <div v-if="selectedApp" class="detail-card pnos-surface">
        <div class="detail-hero"><div class="app-logo large"><span>{{ (selectedApp.name || 'A').slice(0, 1).toUpperCase() }}</span></div><div class="detail-title"><div class="detail-title-row"><h2>{{ selectedApp.name }}</h2><n-tag v-if="selectedApp.official" round size="small" type="info">Official</n-tag></div><p>{{ selectedApp.description || 'Server application' }}</p><span class="rating">Free · Open Source</span></div><n-button type="primary" size="large" :loading="installing === selectedApp.id" @click="install(selectedApp.id)">Get</n-button></div>
        <n-divider />
        <div class="detail-grid"><div><h4>About</h4><p>{{ selectedApp.description || 'Install this application on your pnos server and manage it from one place.' }}</p></div><div><h4>Information</h4><p>Version {{ selectedApp.version }}</p><p v-if="selectedApp.image">{{ selectedApp.image }}</p></div></div>
      </div>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { getStoreApps, installApp } from '@/api'
import { useMessage } from 'naive-ui'
import PageHeader from '@/components/PageHeader.vue'

type AppItem = { id: string; name: string; version: string; description?: string; image?: string; categories?: string[]; official?: boolean }
const message = useMessage()
const apps = ref<AppItem[]>([])
const search = ref('')
const category = ref('all')
const installing = ref('')
const detailVisible = ref(false)
const selectedApp = ref<AppItem | null>(null)
const categoryPills = [{ label: 'All', value: 'all' }, { label: 'Media', value: 'media' }, { label: 'Download', value: 'download' }, { label: 'Tools', value: 'tool' }, { label: 'Network', value: 'network' }]
const filteredApps = computed(() => apps.value.filter(app => {
  const q = search.value.trim().toLowerCase()
  const matchSearch = !q || app.name.toLowerCase().includes(q) || (app.description || '').toLowerCase().includes(q)
  const matchCategory = category.value === 'all' || app.categories?.includes(category.value)
  return matchSearch && matchCategory
}))
const featuredApps = computed(() => filteredApps.value.slice(0, 3))
const restApps = computed(() => filteredApps.value.slice(3))

async function fetchApps() { try { const res: any = await getStoreApps(); apps.value = res.data || [] } catch { message.error('Unable to load apps') } }
async function install(id: string) { installing.value = id; try { await installApp(id); message.success('Installation started') } catch { message.error('Unable to install this app') } finally { installing.value = '' } }
function showDetail(app: AppItem) { selectedApp.value = app; detailVisible.value = true }
function refresh() { fetchApps(); message.success('App catalog refreshed') }
onMounted(fetchApps)
</script>

<style scoped>
.store-tools { padding:14px; margin-bottom:30px; }
.store-search { width:100%; }
.category-pills { display:flex; gap:7px; margin-top:12px; flex-wrap:wrap; }
.pill { border:0; background:transparent; color:#717783; border-radius:9px; padding:7px 12px; cursor:pointer; font-size:12px; font-weight:600; }
.pill.active { color:var(--pnos-primary); background:var(--pnos-primary-soft); }
.store-section { margin-top:24px; }
.section-title-row { display:flex; align-items:end; justify-content:space-between; margin-bottom:12px; }
.section-title-row > span, .section-subtitle { color:var(--pnos-muted); font-size:12px; }
.app-card { padding:18px; cursor:pointer; transition:transform .18s ease, box-shadow .18s ease; min-height:236px; }
.app-card:hover { transform:translateY(-2px); box-shadow:0 12px 32px rgba(17,24,39,.08); }
.app-card-head { display:flex; align-items:flex-start; justify-content:space-between; }
.app-logo { width:54px; height:54px; border-radius:15px; display:grid; place-items:center; background:linear-gradient(145deg,#edf4ff,#f4f0ff); color:#3478f6; font-size:21px; font-weight:750; }
.app-logo.small { width:38px; height:38px; border-radius:11px; font-size:15px; }
.app-logo.large { width:76px; height:76px; border-radius:20px; font-size:30px; flex:none; }
.app-card h3 { margin:18px 0 6px; font-size:17px; letter-spacing:-.02em; }
.app-card p { margin:0; color:var(--pnos-muted); font-size:12px; line-height:1.6; min-height:38px; }
.app-card-footer { display:flex; align-items:center; justify-content:space-between; margin-top:18px; color:var(--pnos-muted); font-size:11px; }
.all-apps { overflow:hidden; }
.list-app { display:flex; align-items:center; gap:12px; padding:14px 16px; border-top:1px solid #f0f1f4; cursor:pointer; }
.list-app:first-child { border-top:0; }
.list-app:hover { background:#fafbfc; }
.list-app-info { flex:1; min-width:0; }
.list-app-info strong { display:block; font-size:13px; }
.list-app-info span { display:block; color:var(--pnos-muted); margin-top:3px; font-size:11px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.empty-store { color:var(--pnos-muted); text-align:center; padding:32px; font-size:13px; }
.detail-card { width:min(760px, calc(100vw - 32px)); padding:28px; }
.detail-hero { display:flex; align-items:center; gap:18px; }
.detail-title { flex:1; }
.detail-title-row { display:flex; align-items:center; gap:8px; }
.detail-title h2 { margin:0; font-size:24px; letter-spacing:-.03em; }
.detail-title p { margin:7px 0; color:var(--pnos-muted); font-size:13px; }
.rating { color:var(--pnos-muted); font-size:11px; }
.detail-grid { display:grid; grid-template-columns:1.4fr 1fr; gap:28px; }
.detail-grid h4 { margin:0 0 8px; font-size:13px; }
.detail-grid p { margin:6px 0; color:var(--pnos-muted); font-size:12px; line-height:1.6; }
@media (max-width:760px) { .detail-hero { align-items:flex-start; flex-wrap:wrap; } .detail-title { min-width:calc(100% - 100px); } .detail-grid { grid-template-columns:1fr; } }
</style>
