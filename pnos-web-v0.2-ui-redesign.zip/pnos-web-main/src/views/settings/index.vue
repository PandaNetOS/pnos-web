<template>
  <div class="pnos-page">
    <PageHeader title="Settings" description="Everything you need to configure your server." />

    <n-input v-model:value="search" placeholder="Search settings" clearable class="settings-search" />

    <div class="settings-grid">
      <SettingsGroup title="System">
        <SettingRow title="General" description="Name, region and basic system information" @click="open('general')" />
        <SettingRow title="Updates" description="System version and update preferences" @click="open('updates')" />
      </SettingsGroup>
      <SettingsGroup title="Hardware & resources">
        <SettingRow title="Storage" description="Disks, mounts and storage pools" @click="open('storage')" />
        <SettingRow title="Network" description="Network interfaces and connections" @click="open('network')" />
      </SettingsGroup>
      <SettingsGroup title="Users & security">
        <SettingRow title="Users & permissions" description="Accounts and access control" @click="open('users')" />
        <SettingRow title="Security" description="Authentication and protection" @click="open('security')" />
      </SettingsGroup>
      <SettingsGroup title="Applications">
        <SettingRow title="App Store" description="Sources and repositories" @click="open('store')" />
        <SettingRow title="Default configuration" description="Defaults for newly installed apps" @click="open('defaults')" />
      </SettingsGroup>
      <SettingsGroup title="About">
        <SettingRow title="About pnos" :description="`${systemStore.info?.version || 'v0.1.0'} · MIT License`" @click="open('about')" />
      </SettingsGroup>
    </div>

    <n-modal v-model:show="detailVisible">
      <div class="detail-panel pnos-surface">
        <div class="detail-header"><div><div class="pnos-eyebrow">Settings</div><h2>{{ detailTitle }}</h2><p>{{ detailDescription }}</p></div><n-button quaternary circle @click="detailVisible = false">×</n-button></div>
        <n-divider />
        <div v-if="selected === 'general'" class="detail-content">
          <n-descriptions :column="1" label-placement="left">
            <n-descriptions-item label="Name">{{ systemStore.info?.name || 'pnos' }}</n-descriptions-item>
            <n-descriptions-item label="Version">{{ systemStore.info?.version || '-' }}</n-descriptions-item>
            <n-descriptions-item label="Operating system">{{ systemStore.info?.os || '-' }}</n-descriptions-item>
            <n-descriptions-item label="Architecture">{{ systemStore.info?.arch || '-' }}</n-descriptions-item>
          </n-descriptions>
        </div>
        <div v-else-if="selected === 'store'" class="detail-content"><n-data-table :columns="sourceColumns" :data="sources" :loading="loadingSources" :bordered="false" /></div>
        <div v-else class="placeholder-detail"><div class="placeholder-icon">○</div><strong>{{ detailTitle }}</strong><p>This area is ready for the next pnos runtime integration.</p></div>
      </div>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { computed, defineComponent, h, onMounted, ref } from 'vue'
import { useSystemStore } from '@/stores/system'
import { getStoreSources } from '@/api'
import PageHeader from '@/components/PageHeader.vue'

const SettingsGroup = defineComponent({ props: { title: { type: String, required: true } }, setup(props, { slots }) { return () => h('section', { class: 'settings-group pnos-surface' }, [h('div', { class: 'group-title' }, props.title), slots.default?.()]) } })
const SettingRow = defineComponent({ props: { title: { type: String, required: true }, description: { type: String, required: true } }, emits: ['click'], setup(props, { emit }) { return () => h('button', { class: 'setting-row', onClick: () => emit('click') }, [h('div', { class: 'setting-icon' }, '○'), h('div', { class: 'setting-copy' }, [h('strong', props.title), h('span', props.description)]), h('span', { class: 'chevron' }, '›')]) } })

const systemStore = useSystemStore()
const sources = ref<any[]>([])
const loadingSources = ref(false)
const search = ref('')
const selected = ref('general')
const detailVisible = ref(false)

const detailTitle = computed(() => ({ general: 'General', updates: 'Updates', storage: 'Storage', network: 'Network', users: 'Users & permissions', security: 'Security', store: 'App Store', defaults: 'Default configuration', about: 'About pnos' } as Record<string, string>)[selected.value] || 'Settings')
const detailDescription = computed(() => ({ general: 'Name and system information', updates: 'Keep pnos up to date', storage: 'Manage disks and storage', network: 'Configure connectivity', users: 'Manage accounts and access', security: 'Authentication and system protection', store: 'Configure application sources', defaults: 'Choose default settings for apps', about: 'The pnos system web interface' } as Record<string, string>)[selected.value] || '')
const sourceColumns = [{ title: 'Name', key: 'name' }, { title: 'URL', key: 'url' }, { title: 'Status', key: 'enabled', render: (row: any) => row.enabled ? 'Enabled' : 'Disabled' }]

async function fetchSources() { loadingSources.value = true; try { const res: any = await getStoreSources(); sources.value = res.data || [] } finally { loadingSources.value = false } }
function open(key: string) { selected.value = key; detailVisible.value = true }

onMounted(() => { systemStore.fetchInfo(); fetchSources() })

void search
</script>

<style scoped>
.settings-search { max-width:640px; margin-bottom:24px; }
.settings-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px; }
.settings-group { padding:7px 0; overflow:hidden; }
.group-title { padding:14px 18px 9px; color:var(--pnos-muted); font-size:12px; font-weight:700; text-transform:uppercase; letter-spacing:.06em; }
.setting-row { width:100%; border:0; background:transparent; display:flex; align-items:center; text-align:left; gap:12px; padding:14px 18px; cursor:pointer; }
.setting-row:hover { background:#fafbfc; }
.setting-icon { width:30px; height:30px; border-radius:9px; background:#f2f4f7; color:#69717c; display:grid; place-items:center; flex:none; }
.setting-copy { flex:1; min-width:0; }
.setting-copy strong { display:block; font-size:13px; }
.setting-copy span { display:block; color:var(--pnos-muted); margin-top:3px; font-size:11px; }
.chevron { color:#9da3ad; font-size:20px; }
.detail-panel { width:min(720px, calc(100vw - 32px)); padding:26px; }
.detail-header { display:flex; align-items:flex-start; justify-content:space-between; gap:16px; }
.detail-header h2 { margin:0; font-size:22px; letter-spacing:-.025em; }
.detail-header p { margin:6px 0 0; color:var(--pnos-muted); font-size:12px; }
.detail-content { min-height:150px; }
.placeholder-detail { min-height:180px; display:flex; align-items:center; justify-content:center; flex-direction:column; text-align:center; }
.placeholder-icon { width:46px; height:46px; display:grid; place-items:center; background:#f2f4f7; border-radius:14px; margin-bottom:12px; color:#69717c; }
.placeholder-detail strong { font-size:14px; }
.placeholder-detail p { color:var(--pnos-muted); font-size:12px; max-width:360px; line-height:1.6; }
@media (max-width:860px) { .settings-grid { grid-template-columns:1fr; } }
</style>
