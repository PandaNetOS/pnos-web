# pnos-web

pnos 系统级 WebUI。v0.2 聚焦三个核心模块：系统概览、应用商店、设置中心。

## 技术栈

- Vue 3 + Vite + TypeScript
- Naive UI
- Pinia
- Vue Router 4
- ECharts
- Axios

## 产品结构

| 路由 | 页面 | 状态 |
|------|------|------|
| /dashboard | 系统概览 | ✅ |
| /store | 应用商店 | ✅ |
| /settings | 设置中心 | ✅ |

容器与文件能力暂时保留在 runtime/API 层以及现有页面源码中，但不再作为一级导航，后续可以在高级设置或应用详情中逐步恢复。

## 设计方向

pnos v0.2 采用克制、系统化、接近 macOS / Apple System Settings 的 UI 语言：

- 信息优先于装饰，状态优先于指标
- 默认隐藏 Docker / Container 等实现细节
- 应用体验接近 App Store
- 设置体验接近系统设置
- 桌面、平板、手机使用响应式布局

## 开发

```bash
npm install
npm run dev
```

开发服务器默认运行在 http://localhost:5173，API 代理到 http://localhost:8080（pnos-runtime）。

## 构建

```bash
npm run build
```

产物在 `dist/` 目录，由 pnos-runtime 托管。

## 许可证

MIT
